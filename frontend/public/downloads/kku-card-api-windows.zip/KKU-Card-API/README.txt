KKU Card API (Windows) — ไม่ต้องใช้ Chrome Extension
1. ติดตั้ง Python 3.10+ จาก python.org
2. ดับเบิลคลิก Start-KKU-Card-API.bat
3. ตั้งค่า URL ใน Admin > อ่านบัตร > ตั้งค่าเครื่องอ่าน → http://127.0.0.1:8000
